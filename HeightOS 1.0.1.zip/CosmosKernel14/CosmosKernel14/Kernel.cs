﻿using Cosmos.HAL.Audio;
using Cosmos.HAL.Drivers.PCI.Audio;
using Cosmos.System.Audio.IO;
using Cosmos.System.Audio;
using IL2CPU.API.Attribs;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Sys = Cosmos.System;
using System.Threading;
using System.Diagnostics;
using static Cosmos.HAL.BlockDevice.ATA_PIO;
using Cosmos.Core.IOGroup;
using Cosmos.HAL;

namespace CosmosKernel14
{
    public class Kernel : Sys.Kernel
    {

        Sys.FileSystem.CosmosVFS fs = new Sys.FileSystem.CosmosVFS();
        string currentdirectory = @"0:\ROOT\ERA\XROOT";
        protected override void BeforeRun()
        {
            Sys.FileSystem.VFS.VFSManager.RegisterVFS(fs);
            if (File.Exists(@"0:\Height\ROOT\ERA\COM##\BOOT.i"))
            {
                
                Console.Clear();
                Console.WriteLine("Welcome Back! HeightOS 1.0.0 started (Custom mode disabled)");
            }
            else
            {
                Console.Clear();
                Console.WriteLine("!!File BOOT.i not found!!");
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("==This is not error==");
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("This is instalation screen, or first start of HeightOS");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("If this is not first start it may be called by error in system");
                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine("After pressing a any key we are check you system");
                Console.ReadKey();
                long freespace = fs.GetAvailableFreeSpace(@"0:\");
                long getspace = fs.GetTotalSize(@"0:\");
                string fstype = fs.GetFileSystemType(@"0:\");
                Console.WriteLine(freespace.ToString(), "- from ");
                Console.Write(getspace.ToString());
                Console.WriteLine("To install Height may be 10gb");
                string CPU = Cosmos.Core.CPU.GetCPUBrandString();
                string CPUV = Cosmos.Core.CPU.GetCPUVendorName();
                uint ARAM = Cosmos.Core.CPU.GetAmountOfRAM();
                ulong AVRAM = Cosmos.Core.GCImplementation.GetAvailableRAM();
                uint URAM = Cosmos.Core.GCImplementation.GetUsedRAM();
                Console.WriteLine(@"CPU: {0} - minimal aviable Intel R pentium 2
CPU Vendor: {1} - Aviable INTEL R, AMD R
Amount of RAM: {2} - Minimal 64mb
Aviable RAM: {3} - minimal Aviable RAM Memory 64mb
Used RAM: {4} / {2}", CPU, CPUV,  ARAM, AVRAM, URAM);
                System.Threading.Thread.Sleep(1000);
                Console.WriteLine("Successfully checked you system aviable for Height OS");
                Console.WriteLine("Instaling after 10 secconds");
                Thread.Sleep(10000);
                Console.Clear();
                Console.WriteLine("Height Instalation process (ITHGHT_INSTAL.hdll)");
                Thread.Sleep(1000);
                fs.CreateDirectory(@"0:\Height\");
                Console.WriteLine("We are don't write logs to screen");
                Console.WriteLine("Starting install");
                fs.CreateFile(@"0:\Height\InstLog.t");
                fs.CreateDirectory(@"0:\Height\ROOT");
                fs.CreateFile(@"0:\Height\ROOT\conf.i");
                File.WriteAllText(@"0:\Height\ROOT\conf.i", @"SYS CHECK CONFIG
CHECK LEVEL: 10 (SUPERUSER)
PRIORITY: 3 (HIGHT LEVEL)
USERROOT: NOREDACT
USEREDIT: SUPERUSER, SYSTEM, USROOT, ROOTUSER, ADV, ABVFA
SYSTEM FILE HEIGHT OS CONFIG NOTICE NOTE ROOT PRIORITY;;;");
                fs.CreateFile(@"0:\Height\ROOT\mms.i");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("Creating new file at ", DateTime.Now);
                fs.CreateFile(@"0:\Height\ROOT\AVB.i");
                Console.WriteLine("Creating new file at ", DateTime.Now);
                fs.CreateFile(@"0:\Height\ROOT\MMD.i");
                Console.WriteLine("Creating new file at ", DateTime.Now);
                fs.CreateFile(@"0:\Height\ROOT\SYSCHECK.i");
                Console.WriteLine("Creating new file at ", DateTime.Now);
                fs.CreateFile(@"0:\Height\ROOT\cABS.i");
                Console.ForegroundColor = ConsoleColor.DarkMagenta;
                Console.WriteLine("Creating new dir at ", DateTime.Now);
                fs.CreateDirectory(@"0:\Height\ROOT\ERA\");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("Creating new file at ", DateTime.Now);
                fs.CreateFile(@"0:\Height\ROOT\ERA\bbi.i");
                Console.WriteLine("Creating new file at ", DateTime.Now);
                fs.CreateFile(@"0:\Height\ROOT\ERA\BMP.i");
                Console.WriteLine("Creating new file at ", DateTime.Now);
                fs.CreateFile(@"0:\Height\ROOT\ERA\SCRIPT.i");
                Console.WriteLine("Creating new file at ", DateTime.Now);
                fs.CreateFile(@"0:\Height\ROOT\ERA\BSD.i");
                Console.WriteLine("Creating new file at ", DateTime.Now);
                fs.CreateFile(@"0:\Height\ROOT\ERA\ASSLOG.i");
                Console.WriteLine("Creating new file at ", DateTime.Now);
                fs.CreateFile(@"0:\Height\ROOT\ERA\SAT.i");
                Console.WriteLine("Creating new file at ", DateTime.Now);
                fs.CreateFile(@"0:\Height\ROOT\ERA\SDD.i");
                Console.WriteLine("Creating new file at ", DateTime.Now);
                fs.CreateDirectory(@"0:\Height\ROOT\ERA\COM##");
                Console.WriteLine("Creating new file at ", DateTime.Now);
                fs.CreateFile(@"0:\Height\ROOT\ERA\COM##\COM00.i");
                Console.WriteLine("Creating new file at ", DateTime.Now);
                fs.CreateFile(@"0:\Height\ROOT\ERA\COM##\COM01.i");
                Console.WriteLine("Creating new file at ", DateTime.Now);
                fs.CreateFile(@"0:\Height\ROOT\ERA\COM##\COM02.i");
                Console.WriteLine("Creating new file at ", DateTime.Now);
                fs.CreateFile(@"0:\Height\ROOT\ERA\COM##\COM03.i");
                Console.WriteLine("Creating new file at ", DateTime.Now);
                fs.CreateFile(@"0:\Height\ROOT\ERA\COM##\HDDLOG.i");
                Console.WriteLine("Creating new file at ", DateTime.Now);
                fs.CreateFile(@"0:\Height\ROOT\ERA\COM##\BOOT.i");
                Console.WriteLine("Creating new file at ", DateTime.Now);
                fs.CreateDirectory(@"0:\Height\XMR\");
                Console.WriteLine("Creating new file at ", DateTime.Now);
                fs.CreateFile(@"0:\Height\XMR\NMM.i");
                Console.WriteLine("Creating new file at ", DateTime.Now);
                fs.CreateFile(@"0:\Height\XMR\NMM1.i");
                Console.WriteLine("Creating new file at ", DateTime.Now);
                fs.CreateFile(@"0:\Height\XMR\NMM.2");
                Console.WriteLine("Creating new file at ", DateTime.Now);
                fs.CreateFile(@"0:\Height\XMR\NMM3.i");
                Console.WriteLine("Creating new file at ", DateTime.Now);
                fs.CreateDirectory(@"0:\Height\XRootable\");
                Console.WriteLine("Creating new file at ", DateTime.Now);
                fs.CreateFile(@"0:\Height\XRotable\XR.i");
                Console.WriteLine("Creating new file at ", DateTime.Now);
                fs.CreateFile(@"0:\Height\XRotable\Rootable.i");
                Console.WriteLine("Creating new file at ", DateTime.Now);
                fs.CreateFile(@"0:\Height\XRotable\Root.i");
                Console.WriteLine("Creating new file at ", DateTime.Now);
                fs.CreateFile(@"0:\Height\XRotable\Host.i");
                Console.WriteLine("Creating new file at ", DateTime.Now);
                fs.CreateFile(@"0:\Height\XRotable\XHost.i");
                Console.WriteLine("Creating new file at ", DateTime.Now);
                fs.CreateFile(@"0:\Height\XRotable\XPR.i");
                Console.WriteLine("Creating new file at ", DateTime.Now);
                fs.CreateFile(@"0:\Height\XRotable\RMBRXBoot.i");
                Console.WriteLine("Creating new file at ", DateTime.Now);
                Console.WriteLine("Rotable loading finaly. . .");
                Console.WriteLine("Creating new file at ", DateTime.Now);
                Thread.Sleep(2000);
                Console.WriteLine("Finish installation! Press any key to reboot");
                Console.ReadKey();
                Restart();
            } }

        protected override void Run()
        {
            //После запуска
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write(currentdirectory + ">> ");
            fs.CreateDirectory(currentdirectory);
            fs.CreateFile(currentdirectory + "commands.ext");
            fs.CreateDirectory(currentdirectory + "ERRORS");
            Commands();

        }
        public void Commands()
        {
            while (true)
            {
                Console.Write(currentdirectory + ">> ");
                var input = Console.ReadLine();
            string filename = "";
            string dirname = "";
            switch (input)
            {

                case "help":
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("shutdown\nreboot\nsysinfo\nhelp\ncd\nmkfile\nmkdir\ndelfile\ndeldir\ndir\nclear");
                    Console.ForegroundColor = ConsoleColor.White;
                    break;
                default:
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Error: uncnown command " + input);
                    Console.ForegroundColor = ConsoleColor.White;
                    break;
                case "shutdown":
                    Console.WriteLine("shutdowning. . .");
                    Cosmos.System.Power.Shutdown();
                    break;
                case "reboot":
                    Console.WriteLine("shutdowning. . .");
                    Cosmos.System.Power.Reboot();
                    break;
                //SysInfo command
                case "sysinfo":
                    string CPUbrand = Cosmos.Core.CPU.GetCPUBrandString();
                    string CPUVendor = Cosmos.Core.CPU.GetCPUVendorName();
                    uint amountRAM = Cosmos.Core.CPU.GetAmountOfRAM();
                    ulong aviale_ram = Cosmos.Core.GCImplementation.GetAvailableRAM();
                    uint Used_ram = Cosmos.Core.GCImplementation.GetUsedRAM();
                    Console.ForegroundColor = ConsoleColor.Gray;
                    Console.WriteLine("=========================");
                    Console.WriteLine(@"CPU: {0}
CPU Vendor: {1}
Amount RAM: {2} MB
Avialable RAM: {3} MB
Used RAM: {4} B", CPUbrand, CPUVendor, amountRAM, aviale_ram, Used_ram);
                    Console.WriteLine("=========================");
                    Console.ForegroundColor = ConsoleColor.White;
                    break;
                case "mkfile":
                    filename = Console.ReadLine();
                    fs.CreateFile(currentdirectory + filename);
                    break;
                case "mkdir":
                    dirname = Console.ReadLine();
                    fs.CreateDirectory(currentdirectory + dirname);
                    break;
                case "delfile":
                    filename = Console.ReadLine();
                    Sys.FileSystem.VFS.VFSManager.DeleteFile(currentdirectory + filename);
                    break;
                case "deldir":
                    dirname = Console.ReadLine();
                    Sys.FileSystem.VFS.VFSManager.DeleteFile(currentdirectory + dirname);
                    break;
                case "cd":
                    Console.Write("Enter directory: ");
                        var Cdlist = Console.ReadLine();
                        if (Cdlist == "%GlobalRoot%")
                        {
                            currentdirectory = @"0:\CosmosOS\Height\";
                        }
                        else
                        {
                            currentdirectory = Cdlist;
                        }
                        
                    break;
                case "dir":
                    try
                    {
                        var directory_list = Sys.FileSystem.VFS.VFSManager.GetDirectoryListing(currentdirectory);
                        foreach (var directoryEntry in directory_list)
                        {
                            try
                            {
                                var entry_type = directoryEntry.mEntryType;
                                if (entry_type == Sys.FileSystem.Listing.DirectoryEntryTypeEnum.File)
                                {
                                    Console.ForegroundColor = ConsoleColor.Magenta;
                                    Console.WriteLine("| <File>       " + directoryEntry.mName);
                                    Console.ForegroundColor = ConsoleColor.White;
                                }
                                if (entry_type == Sys.FileSystem.Listing.DirectoryEntryTypeEnum.Directory)
                                {
                                    Console.ForegroundColor = ConsoleColor.Blue;
                                    Console.WriteLine("| <Directory>      " + directoryEntry.mName);
                                    Console.ForegroundColor = ConsoleColor.White;
                                }
                            }
                            catch (Exception e)
                            {
                                Console.ForegroundColor = ConsoleColor.Red;
                                Console.WriteLine("Error: Directory not found");
                                Console.WriteLine(e.ToString());
                                Console.ForegroundColor= ConsoleColor.White;
                            }

                        }
                    }
                    catch (Exception ex)
                    {
                            Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine(@"Error: no files in directory
or directory uncorect
"+ex.ToString());
                            Console.ForegroundColor = ConsoleColor.White;
                            break;
                    }
                    break;
                case "datetime":
                    Console.WriteLine(DateTime.Now);
                    break;
                case "cls":
                        Console.Clear();
                    break;
                case "analyze":
                    filename = Console.ReadLine();
                    if (File.Exists(currentdirectory + filename))
                    {
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("Exist file: File correct/nbt: NULL");
                        Console.ForegroundColor = ConsoleColor.White;
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Not exist file: File uncorrect/nbt: ERROR IN READ FILE");
                        Console.ForegroundColor = ConsoleColor.White;
                    }
                    break;
                case "error":
                    Console.Clear();
                    fs.CreateFile(currentdirectory + "NaN.null");
                    break;
                case "error null":
                    Console.Clear();
                    OnBoot();
                    fs.CreateFile(currentdirectory + "NaN.null");
                    Sys.FileSystem.VFS.VFSManager.DeleteFile(currentdirectory + "NaN.null");
                    break;
                case "analyzedir":
                    filename = Console.ReadLine();
                    if (Directory.Exists(currentdirectory + dirname))
                    {
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("Exist dir: Dir correct/nbt: NULL");
                        Console.ForegroundColor = ConsoleColor.White;
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Not exist dir: Dir uncorrect/nbt: ERROR IN READ DIR");
                        Console.ForegroundColor = ConsoleColor.White;
                    }
                    break;
                case "hp":
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("shutdown\nreboot\nsysinfo\nhelp\ncd\nmkfile\nmkdir\ndelfile\ndeldir\ndir\nclear");
                    Console.ForegroundColor = ConsoleColor.White;
                    break;
                case "shd":
                    Console.WriteLine("shutdowning. . .");
                    Cosmos.System.Power.Shutdown();
                    break;
                case "rt":
                    Console.WriteLine("shutdowning. . .");
                    Cosmos.System.Power.Reboot();
                    break;
                //SysInfo command
                case "si":
                    CPUbrand = Cosmos.Core.CPU.GetCPUBrandString();
                    CPUVendor = Cosmos.Core.CPU.GetCPUVendorName();
                    amountRAM = Cosmos.Core.CPU.GetAmountOfRAM();
                    aviale_ram = Cosmos.Core.GCImplementation.GetAvailableRAM();
                    Used_ram = Cosmos.Core.GCImplementation.GetUsedRAM();
                    Console.ForegroundColor = ConsoleColor.Gray;
                    Console.WriteLine("=========================");
                    Console.WriteLine(@"CPU: {0}
CPU Vendor: {1}
Amount RAM: {2} MB
Avialable RAM: {3} MB
Used RAM: {4} B", CPUbrand, CPUVendor, amountRAM, aviale_ram, Used_ram);
                    Console.WriteLine("=========================");
                    Console.ForegroundColor = ConsoleColor.White;
                    break;
                case "mf":
                    filename = Console.ReadLine();
                    fs.CreateFile(currentdirectory + filename);
                    break;
                case "md":
                    dirname = Console.ReadLine();
                    fs.CreateDirectory(currentdirectory + dirname);
                    break;
                case "df":
                    filename = Console.ReadLine();
                    Sys.FileSystem.VFS.VFSManager.DeleteFile(currentdirectory + filename);
                    break;
                case "dd":
                    dirname = Console.ReadLine();
                    Sys.FileSystem.VFS.VFSManager.DeleteFile(currentdirectory + dirname);
                    break;
                case "c":
                    Console.Write("Enter directory: ");
                    currentdirectory = Console.ReadLine();
                    break;
                case "d":
                    try
                    {
                        var directory_list = Sys.FileSystem.VFS.VFSManager.GetDirectoryListing(currentdirectory);
                        foreach (var directoryEntry in directory_list)
                        {
                            try
                            {
                                var entry_type = directoryEntry.mEntryType;
                                if (entry_type == Sys.FileSystem.Listing.DirectoryEntryTypeEnum.File)
                                {
                                    Console.ForegroundColor = ConsoleColor.Magenta;
                                    Console.WriteLine("| <File>       " + directoryEntry.mName);
                                    Console.ForegroundColor = ConsoleColor.White;
                                }
                                if (entry_type == Sys.FileSystem.Listing.DirectoryEntryTypeEnum.Directory)
                                {
                                    Console.ForegroundColor = ConsoleColor.Blue;
                                    Console.WriteLine("| <Directory>      " + directoryEntry.mName);
                                    Console.ForegroundColor = ConsoleColor.White;
                                }
                            }
                            catch (Exception e)
                            {
                                Console.WriteLine("Error: Directory not found");
                                Console.WriteLine(e.ToString());
                            }

                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.ToString());
                        break;
                    }
                    break;
                case "dt":
                    Console.WriteLine(DateTime.Now);
                    break;
                case "cl":
                    Console.Clear();
                    break;
                case "az":
                    filename = Console.ReadLine();
                    if (File.Exists(currentdirectory + filename))
                    {
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("Exist file: File correct/nbt: NULL");
                        Console.ForegroundColor = ConsoleColor.White;
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Not exist file: File uncorrect/nbt: ERROR IN READ FILE");
                        Console.ForegroundColor = ConsoleColor.White;
                    }
                    break;
                case "er":
                    Console.Clear();
                    fs.CreateFile(currentdirectory + "NaN.null");
                    break;
                case "ern":
                    Console.Clear();
                    OnBoot();
                    fs.CreateFile(currentdirectory + "NaN.null");
                    Sys.FileSystem.VFS.VFSManager.DeleteFile(currentdirectory + "NaN.null");
                    break;
                case "azd":
                    filename = Console.ReadLine();
                    if (Directory.Exists(currentdirectory + dirname))
                    {
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("Exist dir: Dir correct/nbt: NULL");
                        Console.ForegroundColor = ConsoleColor.White;
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Not exist dir: Dir uncorrect/nbt: ERROR IN READ DIR");
                        Console.ForegroundColor = ConsoleColor.White;
                    }
                    break;
                case "errornulln":
                    while (true)
                    {
                        var r = 10 + 10;
                        Console.WriteLine(Console.ForegroundColor);
                    }
                    case "bcdset":
                        BeforeRun();
                        break;

                    break;
                    case "CMD":
                        while (true)
                        {
                            var ot = Console.ReadLine();
                            switch (ot)
                            {
                                case "DMPCHECK":
                                    Console.WriteLine("Error: strCMD = DMPCHECK ");
                                    Console.WriteLine("                        ^^");
                                    Console.WriteLine("ERROR: Invalid syntax(NO ARGUMENT)");
                                    Console.WriteLine("/f, /im, /q, /e, dir/dmp");
                                    break;
                                case "DMPCHECK /f ":
                                    Console.WriteLine("Error: strCMD = DMPCHECK /f    ");
                                    Console.WriteLine("                            ^^");
                                    Console.WriteLine("ERROR: Invalid syntax(NO ARGUMENT)");
                                    Console.WriteLine("/f, /im, /q, /e, dir/dmp");
                                    break;
                                case "DMPCHECK /im ":
                                    Console.WriteLine("Error: strCMD = DMPCHECK /im   ");
                                    Console.WriteLine("                            ^^");
                                    Console.WriteLine("ERROR: Invalid syntax(NO ARGUMENT)");
                                    Console.WriteLine("/f, /im, /q, /e, dir/dmp");
                                    break;
                                case "DMPCHECK /q ":
                                    Console.WriteLine("Error: strCMD = DMPCHECK /q    ");
                                    Console.WriteLine("                            ^^");
                                    Console.WriteLine("ERROR: Invalid syntax(NO ARGUMENT)");
                                    Console.WriteLine("/f, /im, /q, /e, dir/dmp");
                                    break;
                                case "DMPCHECK /e ":
                                    Console.WriteLine("Error: strCMD = DMPCHECK /e    ");
                                    Console.WriteLine("                            ^^");
                                    Console.WriteLine("ERROR: Invalid syntax(NO ARGUMENT)");
                                    Console.WriteLine("/f, /im, /q, /e, dir/dmp");
                                    break;
                                case "DMPCHECK /f 0:/DMP/C":
                                    Console.WriteLine(@"C - DUMP MADE ...
CODE - MANUALY_INITIADED_CRASH
ERROR - FGDBOOT.hdll STOPED and call error
DRW CHECK - Protection Kernel Panic Error
Kernel:
STOP IN KERNEL DRIVE FILE CLOSED. CRASH INIT
Kernel()
Erd()
BOOT()
KERNEL.CS/DMP/ERROR/0X0034E
KERNEL.CS/FS?CREATE.DMP/C
KERNEL_PANIC()
DEF ERROR: SHUTDOWN>KRPANIC>ERROR
ACPI: STOP BOOT, CRASH A BOOT SECTOR");
                                    break;
                                case "exit":
                                    Run();
                                    break;
                        }
                    }
                }
            }
        }
    }

}

